<?php
include 'db.php';
$id = (int) $_GET['id'];
$result = $conn->query("SELECT * FROM stories WHERE id = $id");
$row = $result->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlspecialchars($row['title']); ?> - Smutica</title>
</head>
<body>
    <h1><?php echo htmlspecialchars($row['title']); ?></h1>
    <p><em>by <?php echo htmlspecialchars($row['author_name']); ?> on <?php echo $row['created_at']; ?></em></p>
    <p><?php echo nl2br(htmlspecialchars($row['content'])); ?></p>
    <br><a href="index.php">Back to Home</a>
</body>
</html>