<?php include 'db.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Smutica - Read Stories</title>
</head>
<body>
    <h1>All Stories</h1>
    <a href="upload.php">Submit a New Story</a><br><br>
    <?php
    $result = $conn->query("SELECT * FROM stories ORDER BY created_at DESC");
    while ($row = $result->fetch_assoc()) {
        echo "<h2><a href='story.php?id=" . $row['id'] . "'>" . htmlspecialchars($row['title']) . "</a></h2>";
        echo "<p><em>by " . htmlspecialchars($row['author_name']) . " on " . $row['created_at'] . "</em></p><hr>";
    }
    ?>
</body>
</html>