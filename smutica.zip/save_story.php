<?php
include 'db.php';

$author_name = $conn->real_escape_string($_POST['author_name']);
$title = $conn->real_escape_string($_POST['title']);
$content = $conn->real_escape_string($_POST['content']);

$sql = "INSERT INTO stories (author_name, title, content) VALUES ('$author_name', '$title', '$content')";
$conn->query($sql);

header("Location: index.php");
exit();
?>