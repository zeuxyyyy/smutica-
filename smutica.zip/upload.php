<!DOCTYPE html>
<html>
<head>
    <title>Submit Story | Smutica</title>
</head>
<body>
    <h1>Submit Your Story</h1>
    <form action="save_story.php" method="post">
        <input type="text" name="author_name" placeholder="Your Name" required><br><br>
        <input type="text" name="title" placeholder="Story Title" required><br><br>
        <textarea name="content" placeholder="Write your story..." rows="10" cols="50" required></textarea><br><br>
        <button type="submit">Submit</button>
    </form>
    <br><a href="index.php">Back to Home</a>
</body>
</html>